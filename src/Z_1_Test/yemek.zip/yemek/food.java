package Z_1_Test.yemek;

public interface food {

     void taste();

     double ucret();

    }
