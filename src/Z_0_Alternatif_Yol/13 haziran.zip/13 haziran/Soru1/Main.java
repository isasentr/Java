package Gun34Homework.Soru1;

public class Main {
    public static void main(String[] args) {
        Student stdnt1 = new Student("Steven", 12);

        System.out.println(stdnt1);
    }
}
