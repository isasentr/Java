package Gun34Homework.Soru3;

public class Subscriber {
    private String name;
    private boolean doYouWannaSubscribe;
    Memberships whichMember;

    public Subscriber(String name, boolean doYouWannaSubscribe, int whichMember) {
        setName(name);
        setDoYouWannaSubscriber(doYouWannaSubscribe);
        setWhichMember(whichMember);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isDoYouWannaSubscribe() {
        return doYouWannaSubscribe;
    }

    public void setDoYouWannaSubscriber(boolean doYouWannaSubscribe) {
        this.doYouWannaSubscribe = doYouWannaSubscribe;
    }

    public Memberships getWhichMember() {
        return whichMember;
    }

    public void setWhichMember(int whichMember) {
        if (whichMember == 1) {
            System.out.println("Welcome to membership Victoria. Your membership is 40 dollar for month you can enjoy the videos , all homework and see you soon.");
            this.whichMember = Memberships.GOLD;
        } else if (whichMember == 2) {
            System.out.println("Welcome to membership Victoria. Your membership is 20 dollar for month you can enjoy the videos and all homework.");
            this.whichMember = Memberships.SILVER;
        } else if (whichMember == 3) {
            System.out.println("Welcome to membership Victoria. Your membership is 10 dollar for month you can enjoy the videos.");
            this.whichMember = Memberships.BRONZE;
        }
    }

    @Override
    public String toString() {
        return "Subscriber" + " " + name + " " + doYouWannaSubscribe + " " + whichMember;
    }
}
