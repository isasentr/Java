package Gun34Homework.Soru3;

public enum Memberships {
    GOLD(1),
    SILVER(2),
    BRONZE(3);

    final int no;

    Memberships(int no) {
        this.no = no;
    }
}
