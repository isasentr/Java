package Gun34Homework.Soru3;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        Scanner number = new Scanner(System.in);
        ArrayList<Subscriber> subscribeArrayList = new ArrayList<>();

        System.out.print("enter your name please:");
        String name = read.next();
        System.out.print("do you want to subscribe ?  y/n :");
        String subscribtion = read.next();
        if (subscribtion.equalsIgnoreCase("y")) {
            System.out.println("for Gold membership press 1\nfor Silver membership press 2\nfor Bronze membership press 3");
            System.out.print("your choice :");
            int secim = number.nextInt();
            if (secim == 1) {
                subscribeArrayList.add(new Subscriber(name, true, 1));
            } else if (secim == 2) {
                subscribeArrayList.add(new Subscriber(name, true, 2));
            } else if (secim == 3) {
                subscribeArrayList.add(new Subscriber(name, true, 3));
            }
        } else if (subscribtion.equalsIgnoreCase("n")) {
            System.out.println("See you when you want to be a member.");
        }

        System.out.println("subscribeArrayList = " + subscribeArrayList);
    }
}
