package Gun34Homework.Soru4;

public class Main {
    public static void main(String[] args) {

        rentApartments apartment1 = new rentApartments("Tudor Vladimirescu", 1, true);

        System.out.println("apartment1 = " + apartment1);

        rentApartments apartment2 = new rentApartments("Valeriu Cupcea", 0, false);

        System.out.println("apartment2 = " + apartment2);
    }
}
