package odev1;

import java.util.ArrayList;

public class Costco implements IDeliveryOptions {
    final int costcoMinFreeDelivery = 15000;

    private int total = 0;

    @Override
    public int getTheTotal(ArrayList<String> arrayList) {
        for (String s : arrayList) {
            int para = Integer. parseInt(s.replaceAll("[A-Z-$]", ""));
            if (s.contains("K")) {
                total += (para * 1000);
            } else {
                total += para;
            }
        }
        return total;
    }

    @Override
    public String isFreeShipping(ArrayList<String> arrayList) {
        if (total > costcoMinFreeDelivery) {
            return "Print you are eligible for free delivery";
        }
        return "print you need to buy ..... amount of item.";
    }
}
