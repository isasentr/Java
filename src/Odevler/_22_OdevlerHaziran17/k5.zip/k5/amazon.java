package Odevler._22_OdevlerHaziran17.Soru_4;

import java.util.ArrayList;

public class Amazon implements IdeliveryOptions {
    final int amazonMinFreeDelivery = 10000;

    private int total = 0;

    @Override
    public int getTheTotal(ArrayList<String> arrayList) {
        for (String s : arrayList) {
            int cash = Integer.parseInt(s.replaceAll("[A-Z-$]", ""));
            if (s.contains("K")) {
                total += (cash * 1000);
            } else {
                total += cash;
            }
        }
        return total;
    }

    @Override
    public String isFreeShipping(ArrayList<String> arrayList) {
        if (total > amazonMinFreeDelivery) {
            return "Print you are eligible for free delivery";
        }
        return "print you need to buy ..... amount of item.";
    }
}
