package odev1;

import java.util.ArrayList;

public interface IDeliveryOptions {
    int getTheTotal(ArrayList<String> arrayList);

    String isFreeShipping(ArrayList<String> arrayList);

}
