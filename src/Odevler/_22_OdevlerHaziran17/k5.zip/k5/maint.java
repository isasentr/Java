package odev1;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Costco costco = new Costco();
        ArrayList<String> stringArrayList = new ArrayList<>();
        stringArrayList.add("$3K");
        stringArrayList.add("$200");
        stringArrayList.add("$1K");
        System.out.print("your total is=");

        System.out.println(costco.getTheTotal(stringArrayList));
        System.out.println(costco.isFreeShipping(stringArrayList));

        Amazon amazon = new Amazon();
        ArrayList<String> stringArrayList1 = new ArrayList<>();
        stringArrayList1.add("$5K");
        stringArrayList1.add("$500");
        stringArrayList1.add("$1K");
        stringArrayList1.add("$900");
        stringArrayList1.add("$4K");

        System.out.print("your total is=");
        System.out.println(amazon.getTheTotal(stringArrayList1));
        System.out.println(amazon.isFreeShipping(stringArrayList1));
    }
}
